<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<footer>
	<div class="footer">
    	<p>版权所有 © 2018-2019 <?php $this->options->title(); ?>  <?php $this->fields->bei; ?> </p>
        <p>Theme Tin by <a href="https://www.e123e.cn">Wind</a> Powered By <a href="https://www.e123e.cn">Typecho</a></p>
    </div>
</footer>


<div id="scrolltop" class="scrolltop">
	<i class="icon-arrow-up"></i>
</div>
<script>

	  
</script>

</body>
</html>

